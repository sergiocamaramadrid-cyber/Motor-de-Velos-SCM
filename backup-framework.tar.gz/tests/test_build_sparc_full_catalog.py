from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from urllib.parse import urlparse

from scripts.build_sparc_full_catalog import (
    MRT_URL,
    ZIP_URL,
    KPC_TO_M,
    MASS_MODEL_COLUMNS,
    UPSILON_BULGE,
    UPSILON_DISK,
    check_local_sparc_data,
    _parse_args,
    _find_existing_master_table,
    _find_existing_rotmod_files,
    add_master_derived_columns,
    load_master_table,
    norm_name,
    parse_mass_models,
    process_rotmod,
)


def test_norm_name_normalizes_spaces_and_case():
    assert norm_name(" ngc 2403 ") == "NGC2403"


def test_find_existing_rotmod_files_searches_data_paths(tmp_path):
    data_root = tmp_path / "data"
    repo_root = tmp_path / "repo"
    (data_root / "Rotmod_LTG" / "nested").mkdir(parents=True)
    (repo_root / "data" / "SPARC" / "raw").mkdir(parents=True)
    (data_root / "Rotmod_LTG" / "nested" / "A_rotmod.dat").write_text("1 2 3 4 5\n")
    (repo_root / "data" / "SPARC" / "raw" / "B_rotmod.dat").write_text("1 2 3 4 5\n")
    found = _find_existing_rotmod_files(data_root, repo_root, rot_dir=data_root / "Rotmod_LTG")
    names = [p.name for p in found]
    assert names == ["A_rotmod.dat", "B_rotmod.dat"]


def test_find_existing_master_table_prefers_existing_paths(tmp_path):
    data_root = tmp_path / "data"
    repo_root = tmp_path / "repo"
    data_root.mkdir(parents=True)
    (repo_root / "data").mkdir(parents=True)
    table = repo_root / "data" / "SPARC_Lelli2016c.mrt"
    table.write_text("header\n")
    found = _find_existing_master_table(data_root, repo_root)
    assert found == table.resolve()


def test_add_master_derived_columns_builds_log_columns():
    master = pd.DataFrame(
        [
            {"Galaxy": "NGC2403", "L_3.6": 2.0, "MHI": 1.0, "RHI": 10.0},
        ]
    )
    out = add_master_derived_columns(master)
    expected_mbar_1e9 = UPSILON_DISK * 2.0 + 1.33 * 1.0
    assert np.isclose(out.loc[0, "logMbar"], np.log10(expected_mbar_1e9) + 9.0)
    sigma = (1.0e9) / (np.pi * (10.0**2) * 1e6)
    assert np.isclose(out.loc[0, "logSigmaHI_out"], np.log10(sigma))


def test_process_rotmod_converts_to_si_and_joins_master_values(tmp_path):
    rotmod_path = tmp_path / "ngc2403_rotmod.dat"
    # r, vobs, err, vgas, vdisk, vbul
    np.savetxt(
        rotmod_path,
        np.array(
            [
                [1.0, 100.0, 2.0, 40.0, 60.0, 10.0],
                [2.0, 120.0, 3.0, 45.0, 70.0, 12.0],
            ]
        ),
    )
    params = {"NGC2403": {"logMbar": 10.2, "logSigmaHI_out": 0.1}}
    out = process_rotmod(rotmod_path, params)
    assert list(out.columns) == ["galaxy", "r_kpc", "g_obs", "g_bar", "logMbar", "logSigmaHI_out"]
    assert len(out) == 2
    expected_g_obs = ((100.0 * 1_000.0) ** 2) / (1.0 * KPC_TO_M)
    expected_g_bar = (
        ((40.0 * 1_000.0) ** 2)
        + (((60.0 * np.sqrt(UPSILON_DISK)) * 1_000.0) ** 2)
        + (((10.0 * np.sqrt(UPSILON_BULGE)) * 1_000.0) ** 2)
    ) / (1.0 * KPC_TO_M)
    assert np.isclose(out.loc[0, "g_obs"], expected_g_obs)
    assert np.isclose(out.loc[0, "g_bar"], expected_g_bar)
    assert np.all(out["logMbar"] == 10.2)
    assert np.all(out["logSigmaHI_out"] == 0.1)


def test_process_rotmod_prefers_hi_density_from_rotmod_when_available(tmp_path):
    rotmod_path = tmp_path / "ngc2403_rotmod.dat"
    with rotmod_path.open("w", encoding="utf-8") as handle:
        handle.write("# Columns: r Vobs eVobs Vgas Vdisk Vbul SHI\n")
        handle.write("1.0 100.0 2.0 40.0 60.0 10.0 1.5\n")
        handle.write("2.0 120.0 3.0 45.0 70.0 12.0 2.0\n")

    params = {"NGC2403": {"logMbar": 10.2, "logSigmaHI_out": -0.5}}
    out = process_rotmod(rotmod_path, params)
    assert np.allclose(out["logSigmaHI_out"], np.log10(2.0))


def test_process_rotmod_detects_shi_column_when_not_last(tmp_path):
    rotmod_path = tmp_path / "ngc2403_rotmod.dat"
    with rotmod_path.open("w", encoding="utf-8") as handle:
        handle.write("# Columns: r Vobs eVobs Vgas SHI Vdisk Vbul\n")
        handle.write("1.0 100.0 2.0 40.0 1.5 60.0 10.0\n")
        handle.write("2.0 120.0 3.0 45.0 2.0 70.0 12.0\n")

    params = {"NGC2403": {"logMbar": 10.2, "logSigmaHI_out": -0.5}}
    out = process_rotmod(rotmod_path, params)
    assert np.allclose(out["logSigmaHI_out"], np.log10(2.0))


def test_parse_mass_models_reads_blocked_mrt(tmp_path):
    mrt_path = tmp_path / "MassModels_Lelli2016c.mrt"
    with mrt_path.open("w", encoding="utf-8") as handle:
        handle.write("# Galaxy: NGC0300\n")
        handle.write("1.0 100.0 40.0 60.0 10.0\n")
        handle.write("2.0 110.0 45.0 65.0 11.0\n")
        handle.write("# Galaxy: NGC0891\n")
        handle.write("1.5 200.0 80.0 90.0 20.0\n")

    parsed = parse_mass_models(mrt_path)
    assert set(parsed.keys()) == {"NGC0300", "NGC0891"}
    assert list(parsed["NGC0300"].columns) == MASS_MODEL_COLUMNS
    assert len(parsed["NGC0300"]) == 2
    assert parsed["NGC0891"].iloc[0]["Vobs_kms"] == pytest.approx(200.0)


def test_parse_args_defaults_match_sparc_paths():
    args = _parse_args([])
    assert args.data_root == "data/SPARC"
    assert args.out == "data/SPARC/sparc_full.csv"


def test_download_urls_use_zenodo():
    assert urlparse(ZIP_URL).netloc == "zenodo.org"
    assert urlparse(MRT_URL).netloc == "zenodo.org"


def test_check_local_sparc_data_raises_clear_error_when_missing(tmp_path):
    with pytest.raises(FileNotFoundError, match="SPARC data not found locally"):
        check_local_sparc_data(tmp_path / "data" / "SPARC")


def test_check_local_sparc_data_accepts_table_and_rotmod(tmp_path):
    data_root = tmp_path / "data" / "SPARC"
    rotmod = data_root / "rotmod"
    rotmod.mkdir(parents=True)
    (data_root / "SPARC_Lelli2016c.mrt").write_text("header\n")
    (rotmod / "NGC0300_rotmod.dat").write_text("1 2 3 4 5\n")
    check_local_sparc_data(data_root)


def test_check_local_sparc_data_accepts_sparc_table2_and_rotmod(tmp_path):
    data_root = tmp_path / "data" / "SPARC"
    rotmod = data_root / "rotmod"
    rotmod.mkdir(parents=True)
    (data_root / "SPARC_table2.mrt").write_text("header\n")
    (rotmod / "NGC0300_rotmod.dat").write_text("1 2 3 4 5\n")
    check_local_sparc_data(data_root)


def test_load_master_table_csv_renames_l36_and_normalizes_galaxy(tmp_path):
    csv_path = tmp_path / "SPARC_Lelli2016c.csv"
    pd.DataFrame(
        [{"Galaxy": " NGC 2403 ", "L36": 1.0, "MHI": 2.0, "RHI": 3.0}]
    ).to_csv(csv_path, index=False)

    out = load_master_table(csv_path)
    assert "L_3.6" in out.columns
    assert out.loc[0, "Galaxy"] == "NGC 2403"
    assert out.loc[0, "Galaxy_norm"] == "NGC2403"


def test_check_local_sparc_data_raises_when_only_prebuilt_catalog_present(tmp_path):
    data_root = tmp_path / "data" / "SPARC"
    data_root.mkdir(parents=True)
    (data_root / "sparc_full.csv").write_text("galaxy,r_kpc,g_obs,g_bar\n")

    with pytest.raises(FileNotFoundError, match="Detected prebuilt catalog"):
        check_local_sparc_data(data_root)


def test_load_master_table_csv_requires_baryonic_columns(tmp_path):
    csv_path = tmp_path / "SPARC_Lelli2016c.csv"
    pd.DataFrame([{"Galaxy": "NGC2403", "L36": 1.0}]).to_csv(csv_path, index=False)

    with pytest.raises(ValueError, match="missing required columns"):
        load_master_table(csv_path)


def test_load_master_table_csv_fails_when_rhi_missing(tmp_path):
    csv_path = tmp_path / "SPARC_Lelli2016c.csv"
    pd.DataFrame(
        [{"Galaxy": "NGC2403", "L_3.6": 1.0, "MHI": 2.0}]
    ).to_csv(csv_path, index=False)

    with pytest.raises(ValueError, match="RHI"):
        load_master_table(csv_path)
